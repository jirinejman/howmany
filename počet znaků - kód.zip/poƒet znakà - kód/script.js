const textareaForm = document.querySelector(".message")
const counterParagraph = document.querySelector(".text-counter")

textareaForm.addEventListener("input", () => {
//  kolik písmen má textarea?
    let lettersCount = textareaForm.value.length

    // obarvení podle počtu znaků
    if (lettersCount >= 80) {
        textareaForm.style.color = "red"
        counterParagraph.style.color = "red"


        // obarvení počtu znaků mezi 40 a 80 na oranžovo
    // } else if (lettersCount >= 40  && lettersCount < 80) {
    //     textareaForm.style.color = "orange"
    //     counterParagraph.style.color = "orange"
        }
    else {
        textareaForm.style.color = "white"
        counterParagraph.style.color = "white"
    }

    // textový obsah odstavce měníme podle počtu písmen v texarea
    counterParagraph.textContent = lettersCount
})